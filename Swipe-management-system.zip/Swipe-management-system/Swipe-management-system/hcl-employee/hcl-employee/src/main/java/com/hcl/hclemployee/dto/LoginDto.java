package com.hcl.hclemployee.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

//@JsonFilter("logDetails")
public class LoginDto {

 
	private Long sapId;
	@JsonIgnore
	private String sapName;
	private Long hclFacilityId;
	private String hclFacilityName;
	private String logType;
	private Date date;

	public Long getSapId() {
		return sapId;
	}

	public void setSapId(Long sapId) {
		this.sapId = sapId;
	}

	public Long getHclFacilityId() {
		return hclFacilityId;
	}

	public void setHclFacilityId(Long hclFacilityId) {
		this.hclFacilityId = hclFacilityId;
	}

	public String getLogType() {
		return logType;
	}

	public void setLogType(String logType) {
		this.logType = logType;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getSapName() {
		return sapName;
	}

	public void setSapName(String sapName) {
		this.sapName = sapName;
	}

	public String getHclFacilityName() {
		return hclFacilityName;
	}

	public void setHclFacilityName(String hclFacilityName) {
		this.hclFacilityName = hclFacilityName;
	}

}
