package com.hcl.hclemployee.repositary;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.hclemployee.entity.Employee;

public interface EmployeeRepositary extends JpaRepository<Employee, Long> {

	public Employee findBysapId(Long sapId);

	public Employee findByEmployeeId(long employeeId);

	public void deleteByEmployeeId(Long employeeId);

	 public Optional<Employee> findById(Long employeeId);

}
