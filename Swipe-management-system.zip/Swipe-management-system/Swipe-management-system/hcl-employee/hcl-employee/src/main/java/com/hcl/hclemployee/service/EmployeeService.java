package com.hcl.hclemployee.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.hcl.hclemployee.dto.EmployeeDto;
import com.hcl.hclemployee.dto.EmployeeReportByDate;
import com.hcl.hclemployee.dto.EmployeeReportResponse;
import com.hcl.hclemployee.dto.ResponseDto;
import com.hcl.hclemployee.entity.Employee;

@Service
public interface EmployeeService {

	public ResponseDto registerEmployee(EmployeeDto employeeDto);

	public EmployeeReportResponse getEmpReport(Long sapId);

	public EmployeeReportResponse getEmpReportBySapIdAndDates(EmployeeReportByDate reqDto);

	public EmployeeReportResponse getEmpReportBySapIdAndCurrentDate(Long sapId);

	public ResponseDto updateEmployee(EmployeeDto employee , Long sapId);

	public void deleteById(Long employeeId);

	public Optional<Employee> findById(Long employeeId);

}
