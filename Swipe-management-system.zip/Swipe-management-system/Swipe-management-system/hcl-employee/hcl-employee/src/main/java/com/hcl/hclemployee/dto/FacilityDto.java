package com.hcl.hclemployee.dto;

import java.util.List;

public class FacilityDto {
	
	private Long facilityId;
	private String facilityName;
	
	List<EmployeeResponseDto> employeeResponseDto;
	
	public Long getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(Long facilityId) {
		this.facilityId = facilityId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public List<EmployeeResponseDto> getEmployeeResponseDto() {
		return employeeResponseDto;
	}
	public void setEmployeeResponseDto(List<EmployeeResponseDto> employeeResponseDto) {
		this.employeeResponseDto = employeeResponseDto;
	}
	
}
