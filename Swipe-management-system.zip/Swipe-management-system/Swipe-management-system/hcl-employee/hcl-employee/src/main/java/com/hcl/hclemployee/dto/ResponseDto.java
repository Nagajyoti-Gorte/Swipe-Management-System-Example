package com.hcl.hclemployee.dto;

import java.util.List;

public class ResponseDto {

	private Integer statusCode;

	private String message;

	private List<FacilityResponseDto> facilityResponseDto;

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<FacilityResponseDto> getFacilityResponseDto() {
		return facilityResponseDto;
	}

	public void setFacilityResponseDto(List<FacilityResponseDto> facilityResponseDto) {
		this.facilityResponseDto = facilityResponseDto;
	}

}
