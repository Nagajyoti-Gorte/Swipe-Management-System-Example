package com.hcl.hclemployee.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class RequestParamException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1424308579686943019L;

	public RequestParamException(String message) {
		super(message);
	}

}
