package com.hcl.hclemployee.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.omg.CORBA.portable.ApplicationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.hcl.hclemployee.dto.EmployeeDto;
import com.hcl.hclemployee.dto.EmployeeReportByDate;
import com.hcl.hclemployee.dto.EmployeeReportResponse;
import com.hcl.hclemployee.dto.FacilityDto;
import com.hcl.hclemployee.dto.LoginDto;
import com.hcl.hclemployee.dto.ResponseDto;
import com.hcl.hclemployee.entity.Employee;
import com.hcl.hclemployee.exception.RecordNotFoundException;
import com.hcl.hclemployee.service.EmployeeService;
import com.hcl.hclemployee.service.FacilityService;
import com.hcl.hclemployee.service.LoginService;

import springfox.documentation.annotations.ApiIgnore;

/**
 * @author Jyoti
 *
 */
/**
 * @author User1
 *
 */
@RestController
public class HclEmployeeController {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	EmployeeService employeeService;

	@Autowired
	FacilityService facilityService;

	@Autowired
	LoginService loginService;

	
	
	
	
	@ApiIgnore
	@GetMapping("/gethclFacilities")
	public ResponseDto getFacilities() {

		String url = "http://localhost:9093/facilities/getListOfFacilities";

		ResponseDto responseDto = restTemplate.getForObject(url, ResponseDto.class);

		return responseDto;
	}

	
	
	@PostMapping("/registerEmployee")
	public ResponseDto registerEMployee(@Valid @RequestBody EmployeeDto employeeDto) {
		return employeeService.registerEmployee(employeeDto);
	}

	@PostMapping("/loginEmployee")
	public ResponseDto loginEmployee(@Valid @RequestBody LoginDto loginDto) {

		return loginService.loginEmployee(loginDto);

	}

	
	@ApiIgnore
	@GetMapping("/facilityReportByfacilityId/{id}")
	public FacilityDto facilityReportByfacilityId(@PathVariable(name = "id") long id) throws ApplicationException {

		FacilityDto facilityDto = facilityService.facilityReportByFaciliId(id);

		return facilityDto;

	}

	@ApiIgnore
	@GetMapping("/employeeDetailsBySapId/{sapId}")
	public EmployeeReportResponse getEmpReportBySap(@Valid @PathVariable("sapId") Long sapId) {
		return employeeService.getEmpReport(sapId);

	}

	@PostMapping("/getEmpReportBySapIdAndDates")
	public EmployeeReportResponse getEmpReportBySapIdAndDates(@Valid @RequestBody EmployeeReportByDate reqDto) {
		return employeeService.getEmpReportBySapIdAndDates(reqDto);

	}

	@GetMapping("/employeeDetailsBySapIdAndCurrentDate/{sapId}")
	public EmployeeReportResponse getEmpReportBySapIdAndCurrentDate(@PathVariable("sapId") Long sapId) {
		return employeeService.getEmpReportBySapIdAndCurrentDate(sapId);

	}

	@PutMapping("/updatetheEmployee/{sapId}")
	public ResponseDto updateEmployee(@RequestBody EmployeeDto employee, @PathVariable Long sapId) {
		return employeeService.updateEmployee(employee, sapId);
	}

	@DeleteMapping("/deleteEmployee/{employeeId}")
	private String deleteEmployee(@PathVariable Long employeeId) throws RecordNotFoundException {
		Optional<Employee> optionalEmployee = employeeService.findById(employeeId);
		if (!optionalEmployee.isPresent()) {
			throw new RecordNotFoundException("Invalid Employee Id" + employeeId);
		}
		employeeService.deleteById(employeeId);
		return "Deleted Employee Id" + employeeId;

	}

}
