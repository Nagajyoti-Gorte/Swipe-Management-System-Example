package com.hcl.hclemployee.service;

import com.hcl.hclemployee.dto.LoginDto;
import com.hcl.hclemployee.dto.ResponseDto;

public interface LoginService {

	public ResponseDto loginEmployee(LoginDto loginDto);

}
