package com.hcl.hclemployee.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hcl.hclemployee.dto.EmployeeDto;
import com.hcl.hclemployee.dto.EmployeeReportByDate;
import com.hcl.hclemployee.dto.EmployeeReportResponse;
import com.hcl.hclemployee.dto.FacilityDto;
import com.hcl.hclemployee.dto.LoginDto;
import com.hcl.hclemployee.dto.ResponseDto;
import com.hcl.hclemployee.entity.Employee;
import com.hcl.hclemployee.entity.EmployeeFacility;
import com.hcl.hclemployee.exception.RecordNotFoundException;
import com.hcl.hclemployee.exception.RequestParamException;
import com.hcl.hclemployee.repositary.EmployeeFAcilityRepositary;
import com.hcl.hclemployee.repositary.EmployeeRepositary;
import com.hcl.hclemployee.util.DateUtil;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	public static String FACILITY_BASE_URL = "http://localhost:9093/facilities";

	@Autowired
	EmployeeRepositary employeeRepositary;

	@Autowired
	EmployeeFAcilityRepositary employeeFAcilityRepositary;

	@Autowired
	RestTemplate restTemplate;

	@Override
	public ResponseDto registerEmployee(EmployeeDto employeeDto) {

		ResponseDto responseDto = new ResponseDto();
		try {
			if (employeeDto.getEmail().isEmpty() || employeeDto.getPhoneNumber().isEmpty()  ) {
				responseDto.setMessage("Employee data is null");
				responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
			} else {
				Employee employee = new Employee();
				
				
				if(!(employeeRepositary.findBysapId(employeeDto.getSapId()) == null)) {
					responseDto.setMessage("Employee already registered with same sapid");
					responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
				}else {

					BeanUtils.copyProperties(employeeDto, employee);

					employee = employeeRepositary.save(employee);

					if (null == employee)
						throw new Exception("employee is null or empty");

					responseDto.setMessage("Success");
					responseDto.setStatusCode(HttpStatus.OK.value());
				}
					

			}

		} catch (Exception e) {
			responseDto.setMessage("Failed" + e.getMessage());
			responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
		}

		return responseDto;

	}

	@Override
	public EmployeeReportResponse getEmpReport(Long sapId) {

		EmployeeReportResponse response = new EmployeeReportResponse();

		try {

			if (sapId == null)
				throw new RecordNotFoundException("sapId param is null or empty");

			else {
				Employee employee = employeeRepositary.findBysapId(sapId);

				if (null == employee)
					throw new RecordNotFoundException("No record found for the employee " + sapId);

				response.setEmpName(employee.getEmployeeName());

				List<EmployeeFacility> employeeFacilities = employeeFAcilityRepositary
						.findByEmployeeId(employee.getEmployeeId());

				List<LoginDto> loginDtos = new ArrayList<LoginDto>();

				for (EmployeeFacility employeeFacility : employeeFacilities) {
					LoginDto loginDto = new LoginDto();
					BeanUtils.copyProperties(employeeFacility, loginDto);
					loginDto.setLogType(employeeFacility.getInOut());

					// Call API to fetch the facility name
					FacilityDto facilityDto = restTemplate.getForObject(
							FACILITY_BASE_URL + "/facilityById/{facilityId}", FacilityDto.class,
							employeeFacility.getHclFacilityId());
					loginDto.setHclFacilityName(facilityDto.getFacilityName());

					loginDtos.add(loginDto);
				}
				response.setLoginDtos(loginDtos);
				response.setSapId(sapId);
				response.setEmpName(employee.getEmployeeName());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public EmployeeReportResponse getEmpReportBySapIdAndDates(EmployeeReportByDate reqDto) {

		EmployeeReportResponse response = new EmployeeReportResponse();

		if (reqDto == null)
			throw new RequestParamException("reqDto param is null or empty");

		if (reqDto.getSapId() == null   )
			throw new RequestParamException("sapId param is null or empty");

		else {
			Employee employee = employeeRepositary.findBysapId(reqDto.getSapId());

			if (null == employee)
				throw new RecordNotFoundException("No record found for the employee " + reqDto.getSapId());

			response.setEmpName(employee.getEmployeeName());

			List<EmployeeFacility> employeeFacilities = employeeFAcilityRepositary
					.findByEmployeeIdAndDates(employee.getEmployeeId(), reqDto.getFromDate(), reqDto.getToDate());

			List<LoginDto> loginDtos = new ArrayList<LoginDto>();

			for (EmployeeFacility employeeFacility : employeeFacilities) {
				LoginDto loginDto = new LoginDto();
				BeanUtils.copyProperties(employeeFacility, loginDto);
				loginDto.setLogType(employeeFacility.getInOut());

				// Call API to fetch the facility name
				FacilityDto facilityDto = restTemplate.getForObject(FACILITY_BASE_URL + "/facilityById/{facilityId}",
						FacilityDto.class, employeeFacility.getHclFacilityId());
				loginDto.setHclFacilityName(facilityDto.getFacilityName());

				loginDtos.add(loginDto);
			}
			response.setLoginDtos(loginDtos);
			response.setSapId(reqDto.getSapId());
			response.setEmpName(employee.getEmployeeName());
		}

		return response;

	}

	@Override
	public EmployeeReportResponse getEmpReportBySapIdAndCurrentDate(Long sapId) {
		EmployeeReportResponse response = new EmployeeReportResponse();

		try {

			if (sapId == null )
				throw new RecordNotFoundException("sapId param is null or empty");

			else {
				Employee employee = employeeRepositary.findBysapId(sapId);

				if (null == employee)
					throw new RecordNotFoundException("No record found for the employee " + sapId);

				response.setEmpName(employee.getEmployeeName());

				Date fmDate = DateUtil.getDate(new Date(), Boolean.FALSE);
				Date toDate = DateUtil.getDate(new Date(), Boolean.TRUE);

				List<EmployeeFacility> employeeFacilities = employeeFAcilityRepositary
						.findByEmployeeIdAndDatesWithSorting(employee.getEmployeeId(), fmDate, toDate,
								Sort.by(Sort.Order.asc("date")));

				List<LoginDto> loginDtos = new ArrayList<LoginDto>();

				for (EmployeeFacility employeeFacility : employeeFacilities) {
					LoginDto loginDto = new LoginDto();
					BeanUtils.copyProperties(employeeFacility, loginDto);
					loginDto.setLogType(employeeFacility.getInOut());

					// Call API to fetch the facility name
					FacilityDto facilityDto = restTemplate.getForObject(
							FACILITY_BASE_URL + "/facilityById/{facilityId}", FacilityDto.class,
							employeeFacility.getHclFacilityId());
					loginDto.setHclFacilityName(facilityDto.getFacilityName());

					loginDtos.add(loginDto);
				}
				response.setLoginDtos(loginDtos);
				response.setSapId(sapId);

				// Set the duration stayed hours
				Date inTime = iterateForInOutRecords(employeeFacilities, "IN");
				Date outTime = iterateForInOutRecords(employeeFacilities, "OUT");
				if (inTime != null && outTime != null) {
					response.setDurStayedHrs(DateUtil.getTimeDifference(outTime, inTime));
				} else
					response.setDurStayedHrs("-");

				response.setEmpName(employee.getEmployeeName());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	private Date iterateForInOutRecords(List<EmployeeFacility> employeeFacilities, String fetchType) {
		try {

			if (fetchType.equals("IN")) {
				for (int i = 0; i < employeeFacilities.size() - 1; i++) {
					if (employeeFacilities.get(i).getInOut().equals(fetchType))
						return employeeFacilities.get(i).getDate();
				}
			} else {
				for (int i = employeeFacilities.size() - 1; i > 0; i--) {
					if (employeeFacilities.get(i).getInOut().equals(fetchType))
						return employeeFacilities.get(i).getDate();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public ResponseDto updateEmployee(EmployeeDto employee, Long sapId) {
		ResponseDto responseDto = new ResponseDto();

		if (employee == null) {
			responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
			responseDto.setMessage("Employee Data is null or empty");
		} else {
			Employee emp = employeeRepositary.findBysapId(sapId);
			BeanUtils.copyProperties(employee, emp);
			employeeRepositary.save(emp);
			responseDto.setStatusCode(HttpStatus.OK.value());
			responseDto.setMessage("Employee data updated successfully");
		}
		return responseDto;
	}

	@Override
	public void deleteById(Long employeeId) {
		employeeRepositary.deleteById(employeeId);

	}

	@Override
	public Optional<Employee> findById(Long employeeId) {
		// TODO Auto-generated method stub
		Optional<Employee> findById = employeeRepositary.findById(employeeId);
		return findById;
	}
}
