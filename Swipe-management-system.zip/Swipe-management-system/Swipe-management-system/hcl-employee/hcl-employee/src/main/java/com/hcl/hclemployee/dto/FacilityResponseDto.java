package com.hcl.hclemployee.dto;

public class FacilityResponseDto {
	
	private String facilityName;
	private String facilityLOcation;
	private String facilityCode;
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getFacilityLOcation() {
		return facilityLOcation;
	}
	public void setFacilityLOcation(String facilityLOcation) {
		this.facilityLOcation = facilityLOcation;
	}
	public String getFacilityCode() {
		return facilityCode;
	}
	public void setFacilityCode(String facilityCode) {
		this.facilityCode = facilityCode;
	}
	
	

}
