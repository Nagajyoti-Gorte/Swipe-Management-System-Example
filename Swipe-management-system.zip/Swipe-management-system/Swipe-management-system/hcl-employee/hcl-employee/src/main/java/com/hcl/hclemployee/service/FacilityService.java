package com.hcl.hclemployee.service;

import com.hcl.hclemployee.dto.FacilityDto;

public interface FacilityService {

	public FacilityDto facilityReportByFaciliId(Long id);

}
