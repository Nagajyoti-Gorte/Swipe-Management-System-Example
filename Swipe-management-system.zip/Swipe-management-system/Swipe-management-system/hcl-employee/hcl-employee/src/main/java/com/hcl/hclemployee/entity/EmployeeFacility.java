package com.hcl.hclemployee.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="EMPLOYEE_FACILITY", uniqueConstraints = {@UniqueConstraint(columnNames = "EMP_FACILITY_ID")})
public class EmployeeFacility implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="EMP_FACILITY_ID")
	private long empFacilityId;
	
	@Column(name="EMPLOYEE_ID")
	private long employeeId;
	
	@Column(name="HCL_FACILITY_ID")
	private long hclFacilityId;
	
	@Column(name="DATE")
	private Date date;
	
	@Column(name="IN_OUT")
	private String inOut;

	public long getEmpFacilityId() {
		return empFacilityId;
	}

	public void setEmpFacilityId(long empFacilityId) {
		this.empFacilityId = empFacilityId;
	}

	public long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	public long getHclFacilityId() {
		return hclFacilityId;
	}

	public void setHclFacilityId(long hclFacilityId) {
		this.hclFacilityId = hclFacilityId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getInOut() {
		return inOut;
	}

	public void setInOut(String inOut) {
		this.inOut = inOut;
	}

	

}
