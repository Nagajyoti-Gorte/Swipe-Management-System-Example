package com.hcl.hclemployee.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.hcl.hclemployee.dto.LoginDto;
import com.hcl.hclemployee.dto.ResponseDto;
import com.hcl.hclemployee.entity.Employee;
import com.hcl.hclemployee.entity.EmployeeFacility;
import com.hcl.hclemployee.repositary.EmployeeFAcilityRepositary;
import com.hcl.hclemployee.repositary.EmployeeRepositary;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	EmployeeRepositary employeeRepositary;

	@Autowired
	EmployeeFAcilityRepositary employeeFAcilityRepositary;

	public ResponseDto loginEmployee(LoginDto loginDto) {
		ResponseDto responseDto = new ResponseDto();
		Employee emp = new Employee();
		try {
			if (loginDto == null || (loginDto != null && loginDto.getSapId() == null)) {
				responseDto.setMessage("Please Swipe the Id card properly");
				responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
			} else {
				EmployeeFacility employeeFacility = new EmployeeFacility();

				emp = employeeRepositary.findBysapId(loginDto.getSapId());

				if (emp == null) {
					responseDto.setMessage("Employee Not Registered, Please Register!!");
					responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
				} else {
					employeeFacility.setEmployeeId(emp.getEmployeeId());
					employeeFacility.setHclFacilityId(loginDto.getHclFacilityId());
					employeeFacility.setDate(new Date());
					employeeFacility.setInOut(loginDto.getLogType());
					employeeFAcilityRepositary.save(employeeFacility);
					
					if(loginDto.getLogType().equals("IN")) {
						responseDto.setMessage("Logged in successfully");
						responseDto.setStatusCode(HttpStatus.OK.value());
					}else {
						responseDto.setMessage("Logged out successfully");
						responseDto.setStatusCode(HttpStatus.OK.value());
					}
				}

			}
		} catch (Exception e) {
			responseDto.setMessage("Failed");
			responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
		}
		return responseDto;
	}
}
