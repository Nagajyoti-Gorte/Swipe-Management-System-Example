package com.hcl.hclemployee.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

public class EmployeeDto {

	private String employeeName;
	private Long sapId;
	
	private String phoneNumber;
	private String department;
	@NotEmpty(message = "Email must not be empty")
	@Email(message = "email should be a valid email")
	private String email;
	private String adress;

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Long getSapId() {
		return sapId;
	}

	public void setSapId(Long sapId) {
		this.sapId = sapId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

}
