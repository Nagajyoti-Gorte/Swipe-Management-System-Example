package com.hcl.hclemployee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.hclemployee.dto.EmployeeResponseDto;
import com.hcl.hclemployee.dto.FacilityDto;
import com.hcl.hclemployee.entity.Employee;
import com.hcl.hclemployee.entity.EmployeeFacility;
import com.hcl.hclemployee.exception.RecordNotFoundException;
import com.hcl.hclemployee.repositary.EmployeeFAcilityRepositary;
import com.hcl.hclemployee.repositary.EmployeeRepositary;

@Service
public class FacilityServiceImpl implements FacilityService {

	@Autowired
	EmployeeFAcilityRepositary employeeFAcilityRepositary;

	@Autowired
	EmployeeRepositary employeeRepositary;
	

	@Override
	public FacilityDto facilityReportByFaciliId(Long id) {
		FacilityDto facilityDto = new FacilityDto();
		try {
			if (id == null)
				new RecordNotFoundException("id param is null or empty");
			else {
				List<EmployeeFacility> employeeFacility = new ArrayList<EmployeeFacility>();

				employeeFacility = employeeFAcilityRepositary.findByHclFacilityId(id);

				List<EmployeeResponseDto> employeeResponseDtos = new ArrayList<EmployeeResponseDto>();

				// set employee details based on facility id
				for (EmployeeFacility empFacility : employeeFacility) {
					EmployeeResponseDto employeeResponseDto = new EmployeeResponseDto();
					Employee employee = employeeRepositary.findByEmployeeId(empFacility.getEmployeeId());
					employeeResponseDto.setEmployeeName(employee.getEmployeeName());
					employeeResponseDto.setSapId(employee.getSapId());
					employeeResponseDto.setLogType(empFacility.getInOut());
					employeeResponseDto.setDate(empFacility.getDate());
					employeeResponseDtos.add(employeeResponseDto);
					facilityDto.setFacilityId(empFacility.getHclFacilityId());
					
				}
				
				facilityDto.setEmployeeResponseDto(employeeResponseDtos);

			}
		} catch (Exception e) {

		}
		return facilityDto;

	}

}
