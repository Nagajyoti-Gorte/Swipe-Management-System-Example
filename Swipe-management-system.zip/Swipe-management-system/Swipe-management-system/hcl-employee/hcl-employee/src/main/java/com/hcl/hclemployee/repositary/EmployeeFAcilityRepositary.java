package com.hcl.hclemployee.repositary;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hcl.hclemployee.entity.EmployeeFacility;

public interface EmployeeFAcilityRepositary extends JpaRepository<EmployeeFacility, Long> {

	public List<EmployeeFacility> findByHclFacilityId(long id);

	public List<EmployeeFacility> findByEmployeeId(Long id);

	@Query("from EmployeeFacility o where o.employeeId= :employeeId and o.date between :fmDate and :toDate")
	public List<EmployeeFacility> findByEmployeeIdAndDates(@Param("employeeId") long employeeId,
			@Param("fmDate") Date fmDate, @Param("toDate") Date toDate);

	@Query("from EmployeeFacility o where o.employeeId= :employeeId and o.date between :fmDate and :toDate")
	public List<EmployeeFacility> findByEmployeeIdAndDatesWithSorting(@Param("employeeId") Long employeeId,
			@Param("fmDate") Date fmDate, @Param("toDate") Date toDate, Sort sort);

}
