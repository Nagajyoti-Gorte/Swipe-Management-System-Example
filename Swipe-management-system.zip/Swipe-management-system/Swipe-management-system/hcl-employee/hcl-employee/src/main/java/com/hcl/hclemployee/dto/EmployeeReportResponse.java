package com.hcl.hclemployee.dto;

import java.util.List;

public class EmployeeReportResponse {

	private Long sapId;

	private String empName;

	private String durStayedHrs;

	private List<LoginDto> loginDtos;

	public Long getSapId() {
		return sapId;
	}

	public void setSapId(Long sapId) {
		this.sapId = sapId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public List<LoginDto> getLoginDtos() {
		return loginDtos;
	}

	public void setLoginDtos(List<LoginDto> loginDtos) {
		this.loginDtos = loginDtos;
	}

	public String getDurStayedHrs() {
		return durStayedHrs;
	}

	public void setDurStayedHrs(String durStayedHrs) {
		this.durStayedHrs = durStayedHrs;
	}

}
