package com.hcl.hclemployee.dto;

import java.util.Date;

import javax.validation.constraints.Past;

public class EmployeeReportByDate {

	// @NotEmpty(message = "SapId should not be null or empty")
	//@NotNull(message = "SapId should not be null")
	private Long sapId;

	@Past(message = "From Date Should be past/previous only")
	private Date fromDate;

	@Past(message = "To Date Should be past/previous only")
	private Date toDate;

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Long getSapId() {
		return sapId;
	}

	public void setSapId(Long sapId) {
		this.sapId = sapId;
	}

}
