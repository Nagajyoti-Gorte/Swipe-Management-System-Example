package com.hcl.hclemployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HclEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
