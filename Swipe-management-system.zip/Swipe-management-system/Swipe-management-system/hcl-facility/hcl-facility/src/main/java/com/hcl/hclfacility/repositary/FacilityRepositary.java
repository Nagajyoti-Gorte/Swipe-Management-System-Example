package com.hcl.hclfacility.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.hclfacility.entity.HclFacility;

public interface FacilityRepositary extends JpaRepository<HclFacility, Long>{
	
	public HclFacility findByFacilityCode(String facilityCode);

}
