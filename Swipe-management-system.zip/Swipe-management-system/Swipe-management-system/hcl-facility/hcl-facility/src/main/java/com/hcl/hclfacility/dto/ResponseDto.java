package com.hcl.hclfacility.dto;

import java.util.List;

public class ResponseDto {

	private Integer statusCode;

	private String message;

	private List<FacilityDto> facilityDto;

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<FacilityDto> getFacilityDto() {
		return facilityDto;
	}

	public void setFacilityDto(List<FacilityDto> facilityDto) {
		this.facilityDto = facilityDto;
	}

}
