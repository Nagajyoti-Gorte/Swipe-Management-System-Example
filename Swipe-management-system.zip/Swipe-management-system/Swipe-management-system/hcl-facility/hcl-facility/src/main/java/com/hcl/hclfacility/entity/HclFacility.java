package com.hcl.hclfacility.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;



/**
 * @author Nagajyoti
 *
 */
@Entity
@Table(name="HCL_FACILITY", uniqueConstraints = {@UniqueConstraint(columnNames = "HCL_FACILITY_ID")})
public class HclFacility implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="HCL_FACILITY_ID" , unique = true)
	private long hclFacilityId;
	
	@Column(name="FACILITY_CODE" , unique=true )
	private String facilityCode;
	
	@Column(name="FACILITY_NAME" , unique = false , length=100)
	private String facilityName;
	
	
	@Column(name="FACILITY_LOCATION" , unique = false , length=100)
	private String facilityLOcation;


	public long getHclFacilityId() {
		return hclFacilityId;
	}


	public void setHclFacilityId(long hclFacilityId) {
		this.hclFacilityId = hclFacilityId;
	}


	public String getFacilityName() {
		return facilityName;
	}


	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}


	public String getFacilityLOcation() {
		return facilityLOcation;
	}


	public void setFacilityLOcation(String facilityLOcation) {
		this.facilityLOcation = facilityLOcation;
	}


	public String getFacilityCode() {
		return facilityCode;
	}


	public void setFacilityCode(String facilityCode) {
		this.facilityCode = facilityCode;
	}
	
	

}
