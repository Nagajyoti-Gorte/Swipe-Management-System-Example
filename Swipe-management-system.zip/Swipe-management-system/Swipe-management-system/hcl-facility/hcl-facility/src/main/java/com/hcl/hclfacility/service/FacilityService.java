package com.hcl.hclfacility.service;

import org.springframework.stereotype.Service;

import com.hcl.hclfacility.dto.FacilityDto;
import com.hcl.hclfacility.dto.FaciltyEmployeeReportDto;
import com.hcl.hclfacility.dto.ResponseDto;
import com.hcl.hclfacility.entity.HclFacility;

@Service
public interface FacilityService {

	public ResponseDto RegisterFacility(FacilityDto facilityDto);

	public ResponseDto getFacilityList();

	public FaciltyEmployeeReportDto getFacilityReportByFacId(Long id);

	public FaciltyEmployeeReportDto getFacilityDetailsById(Long id);

	//public String updateOfficeLocation(HclFacility hclFacility);

	public HclFacility update(HclFacility hclFacility);
}
