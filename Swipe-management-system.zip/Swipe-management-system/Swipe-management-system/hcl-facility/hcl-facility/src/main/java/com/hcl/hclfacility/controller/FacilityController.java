package com.hcl.hclfacility.controller;

import org.omg.CORBA.portable.ApplicationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.hcl.hclfacility.dto.FacilityDto;
import com.hcl.hclfacility.dto.FaciltyEmployeeReportDto;
import com.hcl.hclfacility.dto.ResponseDto;
import com.hcl.hclfacility.entity.HclFacility;
import com.hcl.hclfacility.service.FacilityService;

import springfox.documentation.annotations.ApiIgnore;

@RestController
public class FacilityController {

	@Autowired
	FacilityService facilityService;

	@Autowired
	RestTemplate restTemplate;

	@PostMapping("/registerFacility")
	public ResponseEntity<ResponseDto> registerFacility(@RequestBody FacilityDto facilityDto) {
		ResponseDto responseDto = facilityService.RegisterFacility(facilityDto);
		return new ResponseEntity<>(responseDto, HttpStatus.CREATED);
	}

	@GetMapping("/getListOfFacilities")
	public ResponseDto getFacilityList() {
		ResponseDto responseDto = facilityService.getFacilityList();
		return responseDto;

	}

	@ApiIgnore
	@GetMapping("/facilityById/{facilityId}")
	public FaciltyEmployeeReportDto getFacilityDetailsById(@PathVariable(name = "facilityId") Long id)
			throws ApplicationException {

		FaciltyEmployeeReportDto responseDto = facilityService.getFacilityDetailsById(id);

		return responseDto;
	}

	@GetMapping("/FacilityReportByFacId/{id}")
	public FaciltyEmployeeReportDto getFacilityReportByFacId(@PathVariable(name = "id") Long id) {

		FaciltyEmployeeReportDto responseDto = facilityService.getFacilityReportByFacId(id);

		return responseDto;
	}

	@PutMapping("/UpdateFacilityById/{facilityCode}")
	public ResponseEntity<HclFacility> updateHclFacility(@RequestBody HclFacility hclFacility,
			@PathVariable String facilityCode) {
		return new ResponseEntity<HclFacility>(facilityService.update(hclFacility), HttpStatus.OK);
	}

}
