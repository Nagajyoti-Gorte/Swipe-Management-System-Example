package com.hcl.hclfacility.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hcl.hclfacility.dto.FacilityDto;
import com.hcl.hclfacility.dto.FaciltyEmployeeReportDto;
import com.hcl.hclfacility.dto.ResponseDto;
import com.hcl.hclfacility.entity.HclFacility;
import com.hcl.hclfacility.exception.RecordNotFoundException;
import com.hcl.hclfacility.repositary.FacilityRepositary;

@Service
public class FacilityServiceImpl implements FacilityService {

	private static final String EMPLOYEE_ROOT_URL = "http://localhost:8085/employee";

	@Autowired
	FacilityRepositary facilityRepositary;

	@Autowired
	RestTemplate restTemplate;

	@Override
	public ResponseDto RegisterFacility(FacilityDto facilityDto) {
		HclFacility hclFacility = new HclFacility();
		ResponseDto responseDto = new ResponseDto();

		if (  facilityDto.getFacilityCode().isEmpty() || facilityDto.getFacilityLOcation().isEmpty() || facilityDto.getFacilityName().isEmpty()  ) {
			responseDto.setMessage("Please provide all the fields");
			responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
		} else {
			
			if(facilityRepositary.findByFacilityCode(facilityDto.getFacilityCode()) != null) {
				responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
			    responseDto.setMessage("Facility already registered with same facility code");
			}else {
			BeanUtils.copyProperties(facilityDto, hclFacility);

			if (facilityRepositary.save(hclFacility) != null) {
				responseDto.setStatusCode(HttpStatus.OK.value());
				responseDto.setMessage("Facility Registered SUccessFully");
			} else {
				responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
				responseDto.setMessage("Some thing went wrong Plz try again");
			}
			}
		}
		return responseDto;

	}

	@Override
	public ResponseDto getFacilityList() {
		ResponseDto responseDto = new ResponseDto();
		try {
			List<HclFacility> hclFacility = facilityRepositary.findAll();

			List<FacilityDto> facilityDto = new ArrayList<>();

			for (HclFacility facilit : hclFacility) {
				FacilityDto HclFac = new FacilityDto();
				BeanUtils.copyProperties(facilit, HclFac);
				facilityDto.add(HclFac);
			}

			responseDto.setFacilityDto(facilityDto);
			responseDto.setMessage("Success");
			responseDto.setStatusCode(HttpStatus.OK.value());
		} catch (Exception e) {
			responseDto.setMessage("Failed");
			responseDto.setStatusCode(HttpStatus.EXPECTATION_FAILED.value());
		}
		return responseDto;
	}

	@Override
	public FaciltyEmployeeReportDto getFacilityReportByFacId(Long id) {

		FaciltyEmployeeReportDto responseDto = new FaciltyEmployeeReportDto();
		try {

			if (null == id)
				throw new RecordNotFoundException("id param is null or empty");

			String url = EMPLOYEE_ROOT_URL + "/facilityReportByfacilityId/{id}";
			responseDto = restTemplate.getForObject(url, FaciltyEmployeeReportDto.class, id);

			Optional<HclFacility> optional = facilityRepositary.findById(id);

			if (optional != null && optional.isPresent()) {
				HclFacility facility = optional.get();
				responseDto.setFacilityName(facility.getFacilityName());
			}

			responseDto.setMessage("Success");
			responseDto.setStatusCode(HttpStatus.OK.value());
			return responseDto;
			

		} catch (Exception e) {
			e.printStackTrace();
			responseDto.setMessage("Failed to get the response");
			responseDto.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
		return responseDto;
	}

	@Override
	public FaciltyEmployeeReportDto getFacilityDetailsById(Long id) {

		FaciltyEmployeeReportDto responseDto = new FaciltyEmployeeReportDto();
		try {

			if (null == id)
				throw new RecordNotFoundException("id param is null or empty");

			Optional<HclFacility> optional = facilityRepositary.findById(id);

			if (optional != null && optional.isPresent()) {
				HclFacility facility = optional.get();
				responseDto.setFacilityName(facility.getFacilityName());
				responseDto.setFacilityId(id);
				responseDto.setStatusCode(HttpStatus.OK.value());
				responseDto.setMessage("SUCCESS");
			}

		} catch (Exception e) {
			e.printStackTrace();
			responseDto.setMessage("Failed to get the response");
			responseDto.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
		return responseDto;
	}

	
	@Override
	public HclFacility update(HclFacility hclFacility) {
		// TODO Auto-generated method stub
		return facilityRepositary.save(hclFacility);
	}

	

}
